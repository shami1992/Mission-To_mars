# Bookscraper

## Instructions

* Go to <http://books.toscrape.com/>

* Scrape the titles and the URLs to all books on this fictional online bookstore. Display the results in console.

* That's it!

* If you're craving extra challenge, try scraping all books by **category**. Good luck!
